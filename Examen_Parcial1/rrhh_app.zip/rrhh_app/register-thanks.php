<!doctype html>
<html lang=en>
	<head>
		<title>Registion thank</title>
		<meta charset=utf-8>
		<link rel="stylesheet" type="text/css" href="css/includes.css">
	</head>
	<body>
		<div id="container">
		<?php include("header-admin.php"); ?>
		<!-- <?php //include("nav.php"); ?> -->
		<?php include("info-col.php"); ?>
			<div id="content"><!-- Start of the thank you header content-->
			<h2>Registro exitoso!!!</h2>
			<p>.</p>				
			</div><!-- End of the thank you header content. -->
		</div>	
		<?php include("footer.php"); ?>
	</body>
</html>