<style type="text/css">
	#reg-navigation ul { margin:-165px 15px 0 88%; }
</style>
<div id="header-admin">
	<h1>UAM</h1>
	<h2>PROGRA AVANZADA</h2>
	<div id="reg-navigation">
		<ul>
			<li><a href="../logout.php">Logout</a></li>
			<li><a href="../admin_view_users.php">Listar usuarios</a></li>
			<li><a href="../register-page.php">Agregar usuario</a></li>
			<li><a href="../admin-page.php">Home</a></li>
		</ul>
	</div>
</div>
