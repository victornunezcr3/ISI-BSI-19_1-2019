<div id="header">
	<h1>SISTEMA RRHH</h1>
	<div id="reg-navigation">
		<p>&nbsp;</p>
		<ul>
			<li><a href="index.php">logout</a></li>
		</ul>
	</div>
</div>