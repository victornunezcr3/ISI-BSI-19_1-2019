<style type="text/css">
	#info-col { 
		position:absolute; 
		top:190px; 
		right:10px; 
		color:navy; 
		width:135px; 
		text-align:center; 
		margin:5px 5px 0 0;
	}
</style>
<div id="info-col">
	<h3>Informacion</h3>
		<p>Web design by <br>Victor Ml. Nuñez</p>
		Officia culpa labore elit anim anim <br>
		Lorem adipisicing. Sit fugiat ea fugiat <br>
		nisi laboris amet laborum et officia laboris 
		<p>&nbsp;</p>
</div>
