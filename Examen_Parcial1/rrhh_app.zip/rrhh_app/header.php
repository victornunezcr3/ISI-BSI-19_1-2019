<div id="header">
	<h1>SISTEMA DE RRHH</h1>
	<div id="reg-navigation">
		<ul>
			<li><a href="login.php">Login</a></li>			
		</ul>
	</div>
</div>
