<div id="header-members">
	<h1>UAM</h1>
	<h2>PROGRA AVANZADA</h2>
	<div id="reg-navigation">
		<ul>
			<li><a href="logout.php">Logout</a></li>				
		</ul>
	</div>
</div>
