<div id="nav"><!--The side menu column contains the vertical menu-->
    <h4>Catalogo y mantenimientos</h4>
    <ul>
        <br>
        <br>
        <li><a href="acciones_vista.php" title="consulta empleado">Acciones Personal</a></li>
        <li><a href="register-acc.php" title="ADD">Agregar Accion</a></li>
        <li><a href="../admin-page.php" title="Return to Home Page">Home</a></li>
        <li><a href="../logout.php" title="SALIR">logout</a></li>
    </ul>
</div><!--end of side column and menu -->
