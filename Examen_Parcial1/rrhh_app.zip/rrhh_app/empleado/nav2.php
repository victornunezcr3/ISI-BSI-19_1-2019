<div id="nav"><!--The side menu column contains the vertical menu-->
    <h4>Catalogo y mantenimientos</h4>
    <ul>
        <br>
        <br>
        <li><a href="vista_empleados.php" title="Listar empleados">Empleados</a></li>
        <li><a href="register-page.php" title="Registrar empleados">Registrar empleados</a></li>
        <li><a href="../admin-page.php" title="Return to Home Page">Home</a></li>
        <li><a href="../logout.php" title="SALIR">logout</a></li>
    </ul>
</div><!--end of side column and menu -->
