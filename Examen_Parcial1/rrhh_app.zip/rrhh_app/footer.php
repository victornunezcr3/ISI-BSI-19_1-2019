<style type="text/css">
	#footer { 
		clear:both; 
		margin:auto; 
		height: 19px; 
		text-align:center;
	}
</style>
<div id="footer">
		<p>Copyright &copy; Victor Ml. Nunez 2019 | Designed by <a href="http://www.uamcr.ac.cr/">Victor Nunez</a> | Valid <a href="http://jigsaw.w3.org/css-validator/">CSS</a> &amp; 
		<a href="http://validator.w3.org/">HTML5</a> </p>
</div>
