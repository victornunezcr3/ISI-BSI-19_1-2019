<div id="nav"><!--The side menu column contains the vertical menu-->
    <ul>
        <li><a href="" title="">Consultar empleados</a></li>
        <li><a href="" title="">Consultar departamentos</a></li>
        <li><a href="" title="">Consultar acciones de personal</a></li>
        <li><a href="" title="">Home</a></li>
        <li><a href="index.php" title="Logout">Salir del sistema</a></li>
    </ul>
</div><!--end of side column and menu -->
