<div id="nav"><!--The side menu column contains the vertical menu-->
    <h4>Catalogo y mantenimientos</h4>
    <ul>
        <br>
        <br>
        <li><a href="empleado\vista_empleados.php" title="consulta empleados">Empleados</a></li>
        <li><a href="depa\vista_depa.php" title="Consultar departamentos">Departamentos</a></li>
        <li><a href="accion\acciones_vista.php" title="Listar acciones de personal">Acciones de personal</a></li>
        <li><a href="page-consultas.php" title="Filtrado de tablas">Consultas con filtrado</a></li>
        <li><a href="admin-page.php" title="Return to Home Page">Home</a></li>
        <li><a href="logout.php" title="SALIR">logout</a></li>
    </ul>
</div><!--end of side column and menu -->
